package zad2;
import zas1.Tester;
import java.lang.reflect.*;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InstantiationException {
        Class test = Tester.class;
        Main show = new Main(test);
        Tester t = (Tester) test.newInstance();
    }

    public Class test;

    public Main(Class test){
        this.test = test;
        superClasses();
        constructors();
        methods();
        fields();
        parentFields();
    }

    public void superClasses(){
        superClasses(this.test);
    }

    private void superClasses(Class test){
        if(test.getSuperclass() != null)
            superClasses(test.getSuperclass());
        System.out.println("Super classes: " + test.getName());
    }

    public void constructors(){
        Constructor[] arr = test.getDeclaredConstructors();
        for(Constructor c : arr)
            if(c.getParameterCount() > 0)
                System.out.println("Constructors:" + c);
    }

    public void methods(){
        Method[] arr = test.getDeclaredMethods();
        for(Method c : arr)
            if(!Modifier.isPrivate(c.getModifiers()))
                System.out.println("Methods: " + c);
    }

    public void fields(){
        Field[] arr = test.getFields();
        for(Field c : arr)
            System.out.println("Fields: " + c);
    }

    public void parentFields(){
        Class parent = test.getSuperclass();
        Field[] arr = parent.getDeclaredFields();
        for(Field c : arr)
            if(!Modifier.isPrivate(c.getModifiers()))
                System.out.println("P-Fields: " + c);
    }
}

