package zad3;

import java.beans.*;
import java.io.Serializable;

public
    class Account implements Serializable{
    double money;
    public static int count = 1;
    private VetoableChangeSupport veto = new VetoableChangeSupport(this);
    private PropertyChangeSupport changer = new PropertyChangeSupport(this);
    private int index;
    boolean flag = false;
    public Account(double money) throws PropertyVetoException{
        setMoney(money);
        flag = true;
        setindex(count);
        count++;
    }

    public Account() throws PropertyVetoException{
        setMoney(0);
        flag = true;
        setindex(count);
        count++;
    }

    public void deposit(double dMoney) throws PropertyVetoException{
        setMoney(getmoney()+dMoney);
    }

    public void transfer(Account a, double tMoney) throws  PropertyVetoException{
        this.withdraw(tMoney);
        a.deposit(tMoney);
    }

    public void withdraw(double wMoney) throws PropertyVetoException{
        setMoney(getmoney()-wMoney);
    }


    public String toString(){
        return money + "";
    }

    public synchronized void addPropertyChangeListener(PropertyChangeListener l) {
        changer.addPropertyChangeListener(l);
    }

    public synchronized void removePropertyChangeListener(PropertyChangeListener l) {
        changer.removePropertyChangeListener(l);
    }

    public synchronized void addVetoableChangeListener(VetoableChangeListener l) {
        veto.addVetoableChangeListener(l);
    }

    public synchronized void removeVetoableChangeListener(VetoableChangeListener l) {
        veto.removeVetoableChangeListener(l);
    }

    public int getindex(){
        return index;
    }

    public synchronized void setindex(int newIndex) throws PropertyVetoException {
        int oldIndex = index;
        veto.fireVetoableChange("index", oldIndex, newIndex);
        this.index = newIndex;
        changer.firePropertyChange("index", oldIndex, newIndex);
    }

    public double getmoney() {
        return money;
    }

    public synchronized void setMoney(double newMoney) throws PropertyVetoException {
        double oldVal = money;
        if(flag)
            System.out.print(index + ": ");
        veto.fireVetoableChange("money", oldVal, newMoney);
        this.money = newMoney;
        changer.firePropertyChange("money", oldVal, newMoney);
    }
}
