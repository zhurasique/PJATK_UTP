package zad3;

import java.beans.*;

public
    class AccountLimitator implements VetoableChangeListener {

    int count;

    public AccountLimitator(int count){
        this.count = count;
    }

    @Override
    public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
        double newVal = (double) evt.getNewValue();
        if(newVal < count) throw new PropertyVetoException("Unacceptable value change: " + newVal, evt);
    }
}
