package zad3;

import java.beans.*;

public
    class AccountChange implements PropertyChangeListener {

    public AccountChange(){

    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        double oldVal = (double) evt.getOldValue(),
                newVal = (double) evt.getNewValue();
        System.out.println("Value change from " + oldVal + " to " + newVal);
    }
}
