/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public
class getBigDecimal extends BigDecimal {


    public getBigDecimal(String val) {
        super(val);
    }

    @Override
    public BigDecimal divide(BigDecimal divisor) {
        return super.divide(divisor, 10, RoundingMode.HALF_UP);
    }
}