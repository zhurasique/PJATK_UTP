/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.HashMap;
import java.util.Map;


public
class Calc{

    public String doCalc(String cm) {

        BigDecimal first, second, third;
        String cmd[];
        Map<String, Method> znaki = new HashMap<String, Method>();

        try {

            znaki.put("-",
                    getBigDecimal.class.getMethod("subtract", BigDecimal.class,MathContext.class));

            znaki.put("+",
                    getBigDecimal.class.getMethod("add", BigDecimal.class,MathContext.class));

            znaki.put("*",
                    getBigDecimal.class.getMethod("multiply", BigDecimal.class,MathContext.class));

            znaki.put("/",
                    getBigDecimal.class.getMethod("divide", BigDecimal.class,MathContext.class));

            cmd = cm.split(" ");

            first = new getBigDecimal(cmd[0]);
            second = new getBigDecimal(cmd[2]);
            third = (BigDecimal) znaki.get(cmd[1]).invoke(first, second,MathContext.DECIMAL32);

            return String.valueOf(third);
        } catch (Exception ex) {
            return "Invalid command to calc";
        }
    }
}