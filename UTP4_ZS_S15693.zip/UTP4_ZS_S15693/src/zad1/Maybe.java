/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.util.function.*;
import java.util.NoSuchElementException;

public 
	class Maybe<T> {
	
    public T obj;
    
    private Maybe (T obj){
        this.obj = obj;
    }
    
    public static <S> Maybe<S> of (S obj){
        return new Maybe<>(obj);
    }
    
    public void ifPresent(Consumer<T> cons){
        if (obj != null)	cons.accept(obj);
    }
    
    public <S> Maybe<S> map(Function<T,S> fun){
        if (obj == null) 	return new Maybe<>(null);
        
        S newObject = fun.apply(obj);
        return new Maybe<>(newObject);
    }
    
    public T get(){
        if(obj == null)
            throw new NoSuchElementException("  maybe is empty");
        return obj;
    }
    
    public boolean isPresent(){
        return obj != null;
    }

    public T orElse(T def) {
        if(obj != null)		return obj;
        else	return def;
    }
    public Maybe<T> filter(Predicate<T> pre){
        if (pre.test(obj))		return this;
        return new Maybe<>(null);
    }
    public String toString(){
        if (obj != null)		return "Maybe has value " + obj;
        return "Maybe is empty";
    }
}
