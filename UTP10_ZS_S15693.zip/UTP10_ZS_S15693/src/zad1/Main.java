package zad1;

import javax.swing.*;
import java.awt.event.*;
import java.util.concurrent.*;
import java.lang.reflect.*;

public class Main extends JFrame implements ActionListener {

    JTextArea ta = new JTextArea(40,20);

    Main() {
        super("Thread pool");
        add(new JScrollPane(ta));
        JPanel p = new JPanel();
        JButton b = new JButton("Thread1");
        b.addActionListener(this);
        p.add(b);
        b = new JButton("Thread2");
        b.addActionListener(this);
        p.add(b);
        b = new JButton("Thread3");
        b.addActionListener(this);
        p.add(b);
        b = new JButton("Thread4");
        b.addActionListener(this);
        p.add(b);
        add(p, "South");
        JPanel pp = new JPanel();
        JButton bb = new JButton("Stop");
        bb.addActionListener(this);
        pp.add(bb);
        add(pp, "North");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)  {
        JButton btn = (JButton) e.getSource();
        String cmd = e.getActionCommand();
        try {
            Method m = this.getClass().getDeclaredMethod("task" + cmd);
            m.invoke(this);
        } catch(Exception exc) { exc.printStackTrace(); }
    }


    class SumTask implements Callable<Integer> {
        private int taskNum, limit;

        public SumTask(int taskNum, int limit) {
            this.taskNum = taskNum;
            this.limit = limit;
        }

        public Integer call() throws Exception {
            int sum = 0;
            while(sum < limit) {
                int i = (int) (Math.random()*100);
                if (Thread.currentThread().isInterrupted()) return null;
                sum += i;
                ta.append("Thread " + taskNum + " (limit = " + limit + "); " + i + " ,sum = " + sum + '\n');
                Thread.sleep(1000);
            }
            ta.append("Thread " + taskNum + " done!");
            return sum;
        }
    };

    Future<Integer> task;
    ExecutorService exec = Executors.newFixedThreadPool(4);

    public void taskThread1() {
        try {
            task = exec.submit(new SumTask(1, 1000));
        } catch(RejectedExecutionException exc) {
            ta.append("Execution rejected\n");
            return;
        }
    }

    public void taskThread2() {
        try {
            task = exec.submit(new SumTask(2, 2000));
        } catch(RejectedExecutionException exc) {
            ta.append("Execution rejected\n");
            return;
        }
    }

    public void taskThread3() {
        try {
            task = exec.submit(new SumTask(3, 3000));
        } catch(RejectedExecutionException exc) {
            ta.append("Execution rejected\n");
            return;
        }
    }

    public void taskThread4() {
        try {
            task = exec.submit(new SumTask(4, 4000));
        } catch(RejectedExecutionException exc) {
            ta.append("Execution rejected\n");
            return;
        }
    }

    public void taskStop() {
        task.cancel(true);
    }


    public static void main(String[] args) {
        new Main();
    }

}