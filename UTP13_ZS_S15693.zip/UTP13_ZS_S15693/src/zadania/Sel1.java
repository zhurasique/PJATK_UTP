package zadania;

import java.sql.*;

public class Sel1 {

    static public void main(String[] args) {
        new Sel1();
    }

    Sel1() {

        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:derby:Z:/DerbyDbs/ksidb");
        } catch (Exception exc)  {
            System.out.println(exc);
            System.exit(1);
        }

        String sel = "SELECT * FROM POZYCJE";
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sel);
            while (rs.next()) {
                String nazwisko = rs.getString("NAME");
                int rok = rs.getInt("ROK");
                int cena = rs.getInt("CENA");

                while(rok == 2000 && cena > 30) {
                    System.out.println("Autor: " + nazwisko);
                    System.out.println("Rok:" + rok);
                    System.out.println("Cena:" + cena);
                }
            }
            stmt.close();
            con.close();
        } catch (SQLException exc) {
            System.out.println(exc.getMessage());
        }

        sel = "SELECT * FROM POZYCJE";
        try  {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sel);
            ResultSetMetaData rsmd = rs.getMetaData();
            int cc = rsmd.getColumnCount();
            for (int i = 1; i <= cc; i++)
                System.out.print(rsmd.getColumnLabel(i) + "     ");

            System.out.println("\n------------------------------ przewijanie do g�ry");

            System.out.println(rs.getString("ISBN") + "  " +
                            rs.getString("AUTID") + "  " +
                            rs.getString("TYTUL") + "  " +
                            rs.getString("WYDID") + "  " +
                            rs.getString("ROK") + "  " +
                            rs.getString("CENA"));

            System.out.println("\n----------------------------- pozycjonowanie abs.");
            int[] poz =  { 3, 7, 9  };
            for (int p = 0; p < poz.length; p++)  {
                System.out.print("[ " + poz[p] + " ] ");
                while(p == poz[p])
                for (int i = 1; i <= cc; i++) System.out.print(rs.getString(i) + ", ");
                System.out.println("");
            }
            stmt.close();
            con.close();
        } catch (SQLException exc)  {
            System.out.println(exc.getMessage());
        }
    }
}

