package zadania;

import java.sql.*;

public class Ins1 {

    static public void main(String[] args) {
        new Ins1();
    }

    PreparedStatement stmt;

    Ins1() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:derby:Z:/DerbyDbs/ksidb");
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }
        // nazwy wydawców do wpisywania do tabeli
        String[] wyd = {"PWN", "PWE", "Czytelnik", "Amber", "HELION", "MIKOM"};

        // pierwszy numer wydawcy do wpisywania do tabeli: PWN ma numer 15, PWE ma 16, ...
        int beginKey = 15;

        String[] ins =  {"INSERT INTO AUTOR VALUES (15,'" + wyd[0] +"')",
                "INSERT INTO AUTOR VALUES (16,'" + wyd[1] +"')",
                "INSERT INTO AUTOR VALUES (17,'" + wyd[2] +"')",
                "INSERT INTO AUTOR VALUES (18,'" + wyd[3] +"')",
                "INSERT INTO AUTOR VALUES (15,'" + wyd[4] +"')",
                "INSERT INTO AUTOR VALUES (19,'" + wyd[5] +"')"};// ? ... tablica instrukcji SQL do wpisywania rekordów do tabeli: INSERT ...

        int insCount = 0;   // ile rekordów wpisano
        try {
            for (int i = 0; i < ins.length; i++){
                Statement s = con.createStatement();
                insCount++;
                s.executeUpdate(ins[i]);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        beginKey = 15;
        int delCount =  0;
        try  {
            // przygotowanie instrukcji prekompilowanej
            stmt = con.prepareStatement("DELETE FROM FROM AUTOR WHERE NAME = ?");	// usunięcie z tabeli WYDAWCA rekordu o podanej nazwie wydawcy z tablicy wyd lub o podanym numerze wydawcy zaczynającym się od beginKey
            for (int i=0; i < wyd.length; i++)   {
                delCount++;
                stmt.setString(i, wyd[i]);
                stmt.executeUpdate();
            }
            con.close();
        } catch(SQLException exc)  {
            System.out.println(exc);
        }
    }
}