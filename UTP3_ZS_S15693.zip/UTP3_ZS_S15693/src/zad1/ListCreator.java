/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

public class ListCreator<T> {

    private List<T> newL;
    private ListCreator(List<T> src){
        newL = new ArrayList<>();
        newL.addAll(src);
    }
    public static <S> ListCreator<S> collectFrom(List<S> arg){
        return new ListCreator<>(arg);

    }
    public ListCreator<T> when(Predicate<T> sobj){
        List<T> replace = new ArrayList<>();
        for (T check: newL)
            if (sobj.test(check)){
                replace.add(check);
            }
        newL = replace;
        return this;
    }
    public <S> List<S> mapEvery(Function<T, S> map){

        List<S> newList = new ArrayList<>();
        for (T obj: newL){
            newList.add(map.apply(obj));
        }
        return newList;
    }

}
