/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zad3;

import java.util.function.Function;

@FunctionalInterface
public 
	interface Lambd<T> extends Function {
	
	@Override
	default Function compose(Function before) {
		return null;
	}

	@Override
	default Function andThen(Function after) {
		return null;
	}

	@Override
	default Object apply(Object o) {
		return null;
	}
	
	public T nextOne(Object o);
}
