/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad4;

public 
	class InputConverter<T> {
	
	private static int count = 0;
	private T file;
	private Object obj;
	private Object newObj;

	public InputConverter(T file) {
		this.file = file;
		obj = file;
	}

	public <T> T convertBy(Lambd ... convert) {
		if (count < convert.length) {
			obj = convert[count].nextOne(obj);
			count++;
			convertBy(convert);
		}else {
			newObj = obj;
			obj = file;
		}
		count = 0;
		return (T) newObj;
	}
}
