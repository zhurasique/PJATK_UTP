/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad2;

import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

public 
	class XList<T> extends LinkedList<T> {

	private static final long serialVersionUID = 1L; // - nie potrzebne

	public XList() {
        super();
    }
	
	public XList(T... args) {
        super(new ArrayList<T>(Arrays.asList(args)));
    }

	public XList(Collection<T> type) {
        super(type);
    }

	public static XList<String> splitX(String sym, String split) {
        String[] xlist = sym.split(split);
        return new XList<String>(xlist);
    }

	public static <T> XList<T> of(T... args) {
        T[] xlist = args;
        return new XList<T>(xlist);
    }

	public static <Type> XList<Type> of(Collection<Type> set) {
        return new XList<Type>(set);
    }

	public static XList<String> charsOf(String str) {
        return new XList<String>(splitX(str, ""));
    }

    public static XList<String> tokensOf(String... sym) {
        if (sym.length -1  == 0) {
        	XList<String> xlist = new XList<String>(splitX(sym[0], " "));
            return xlist;
        }
        String smth = "";
        for (int n = 0; n <= sym.length - 1; n++)
        	smth += sym[n];
        XList list = splitX(smth, sym[sym.length - 1]);
        return new XList<String>(list);
    }

    public XList<T> union(Collection<T> coll) {
        XList<T> xlist = new XList(this);
        xlist.addAll(coll);
        return xlist;
    }

    public XList<T> union(T... args) {
        XList<T> xlist = new XList(this);
        for (T j : args) 
        	xlist.add(j);
        return xlist;
    }

    public XList<T> diff(Collection<T> args) {
        XList<T> xlist =  new XList<T>(this);
        xlist.removeAll(args);
        return xlist;
    }

    public XList<T> unique() {
        return new XList<T>(new LinkedHashSet<T>(this));
    }


    public void forEachWithIndex(BiConsumer<T, Integer> args) {
        for(int i = 0; i < this.size(); i++) 
        	args.accept(this.get(i), i);
    }

    public String join(String args) {
        String string = this.stream().map(lista -> lista.toString()).collect(Collectors.joining(args));
        return string;
    }

    public String join() {
        String string = this.stream().map(g -> g.toString()).collect(Collectors.joining(""));
        return string;
    }

    public <Type, Type1> XList<Type> collect(Function<T, Type1> args){
        XList<Type1> xline = new XList<Type1>();
        for(int i = 0; i < this.size(); i++)
        	xline.add(args.apply(this.get(i)));
        return (XList<Type>) xline;
    }

}
