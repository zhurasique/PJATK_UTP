/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.io.*;
import java.util.*;

public class Anagrams {

	public List<ArrayList<String>> mainList = new ArrayList<ArrayList<String>>();
	public List<String> words = new ArrayList<String>();
	
	public Anagrams(String file) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(file));
		while (sc.hasNext())
			words.add(sc.next());
		sc.close();
		
		testAnagram();
	}
	
	public void testAnagram() {
		while (!words.isEmpty()) {
			List<String> arrL = new ArrayList<String>();
			String tmp = words.remove(0);
			arrL.add(tmp);
			for (int i = 0; i < words.size(); i++) {
				String wordI = words.get(i);
				char[] arr1 = tmp.toCharArray();
				char[] arr2 = wordI.toCharArray();
				Arrays.sort(arr1);
				Arrays.sort(arr2);
				if (Arrays.equals(arr2, arr1)) {
					words.remove(i);
					arrL.add(wordI);
					i--;
				}
			}
			mainList.add(new ArrayList<String>(arrL));
		}
	}
	
	public List<ArrayList<String>> getSortedByAnQty() {
		mainList.sort(new Comparator<List<String>>() {
			public int compare(List<String> arr1, List<String> arr2) {
				if (arr2.size() != arr1.size())
					return arr2.size() - arr1.size();
				else if (arr1.get(0).compareTo(arr2.get(0)) > 0)
					return 1;
				return -1;
			}
		});
		return mainList;
	}
	public String getAnagramsFor(String file) {
		for (int i = 0; i < mainList.size(); i++) {
			ArrayList<String> tmp = mainList.get(i);
			String sa = tmp.get(0);
			if (sa.equals(file)) {
				tmp.remove(0);
				return file + ": " + tmp;
			}
		}
		return null;
	}

}
