import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by andud on 09.11.17.
 */
public class Agent {
    public static String[] requests = {"NEW", "ADD", "NET", "CLOSE", "CLK", "SYN", "DEL", "DELAGENT"};
    private String ip;
    private int port;
    private String monitorIp;
    private int monitorPort;
    private ConcurrentHashMap<Integer, String> portIp;
    private int licznik;
    private Thread serverThread;
    private Thread counterThread;
    private boolean work = true;

    public static void main(String[] args)  throws Exception{
        if (args.length==1)
            new Agent(Integer.parseInt(args[0]), 0);
        else
            new Agent(Integer.parseInt(args[1]), 0, "localhost", Integer.parseInt(args[0]));
        Thread.sleep(1000);
    }

    public Agent(int port, int licznik) {

        portIp = new ConcurrentHashMap<>();
        this.port = port;
        this.licznik = licznik;
        monitorPort = 30090;
        monitorIp = "localhost";
        try {
            ip = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        portIp.put(port, ip);

        log("Added agent with ip: " + ip + " and port: " + port);

        createThreads();
        serverThread.start();
        counterThread.start();
        try {
            connectToMonitor();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Agent(int newport, int licznik, String existedIp, int existedPort) {
        this.port = newport;
        monitorPort = 30090;
        monitorIp = "localhost";
        try {
            this.ip = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        this.licznik = licznik;

        log("Added new agent with ip: " + ip + " and port: " + port);

        createThreads();
        connectWithOther(existedIp, existedPort);
        serverThread.start();
        counterThread.start();
        try {
            connectToMonitor();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void msg(String msg, BufferedWriter bw) throws IOException {
        bw.write(msg);
        bw.newLine();
        bw.flush();

    }

    public void log(String msg) {
        System.out.println("AGENT LOG: " + port + " " + msg);
    }

    private void createThreads() {
        serverThread = new Thread(() -> {
            try {
                while (work) {
                    ServerSocket thisAgentSocket = new ServerSocket(port);
                    log("Started working");
                    log("KNOWN AGENTS: " + portIp);
                    Socket otherAgentSocket = thisAgentSocket.accept();
                    log("Agent connected");
                    BufferedReader br = new BufferedReader(new InputStreamReader(otherAgentSocket.getInputStream(), "UTF-8"));
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(otherAgentSocket.getOutputStream()));

                    String request = br.readLine();
                    while (!request.equals(requests[3])) {

                        if (request.equals(requests[0]))
                            newAgent(bw, br);
                        else if (request.equals(requests[1]))
                            addAgent(bw, br);
                        else if (request.equals(requests[2]))
                            net(bw);
                        else if (request.equals(requests[4]))
                            clk(bw);
                        else if (request.equals(requests[5])) {
                            syn();
                            msg("NEW VALUE: " + licznik, bw);
                        } else if (request.equals(requests[6])) {
                            del(ip, port);
                            work = false;
                            counterThread.interrupt();
                            msg("200", bw);
                            log("DELETED");
                            break;
                        } else if (request.equals(requests[7]))
                            del(br, bw);
                        request = br.readLine();
                    }

                    thisAgentSocket.close();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }

        });

        counterThread = new Thread(() -> {
            boolean run = true;
            while (run) {
                try {
                    licznik++;
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    run = false;
                }
            }
        });

    }

    private void newAgent(BufferedWriter bw, BufferedReader br) throws IOException {

        msg("PORT", bw);
        int agentPort = Integer.parseInt(br.readLine());
        msg("IP", bw);
        String agentIp = br.readLine();

        if (!portIp.containsKey(agentPort)) {
            addToEveryone(agentPort, agentIp);
            msg("SUCCESS", bw);
        } else
            msg("FAILED, AGENT ALREADY EXISTS", bw);

    }

    private void addToEveryone(int port, String ip) throws IOException {
        for (Map.Entry<Integer, String> entry : portIp.entrySet()) {
            if (entry.getKey() == this.port && entry.getValue().equals(this.ip)) {
                portIp.put(port, ip);
            } else if (entry.getKey() == port && entry.getValue().equals(ip)) {
                continue;
            } else {
                Socket agentSocket = new Socket(entry.getValue(), entry.getKey());
                BufferedReader br = new BufferedReader(new InputStreamReader(agentSocket.getInputStream(), "UTF-8"));
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(agentSocket.getOutputStream()));
                msg(requests[1], bw);
                msg(port + "", bw);
                msg(ip, bw);
                msg(requests[3], bw);
            }
        }

    }

    private void connectWithOther(String ip, int port) {

        try {

            log("STARTED CONNECTION ");
            Socket agentSocket = new Socket(ip, port);
            BufferedReader br = new BufferedReader(new InputStreamReader(agentSocket.getInputStream(), "UTF-8"));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(agentSocket.getOutputStream()));

            msg(requests[0], bw);
            String response = br.readLine();
            msg(this.port + "", bw);
            br.readLine();
            msg(this.ip, bw);
            msg(requests[2], bw);
            portIp = new ConcurrentHashMap<>();
            response = br.readLine();
            response = br.readLine();
            while (!response.equals("101")) {
                int np = Integer.parseInt(response);
                String nip = br.readLine();
                portIp.put(np, nip);
                response = br.readLine();
            }
            msg(requests[3], bw);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void net(BufferedWriter bw) throws IOException {

        for (Map.Entry<Integer, String> entry : portIp.entrySet()) {

            msg(entry.getKey() + "", bw);
            msg(entry.getValue(), bw);

        }

        msg("101", bw);


    }

    private void clk(BufferedWriter bw) throws IOException {

        log("SENDING COUNTER VALUE");

        msg(licznik + "", bw);

    }

    private void addAgent(BufferedWriter bw, BufferedReader br) throws IOException {
        msg("WAITING FOR PORT", bw);
        int portNum = Integer.parseInt(br.readLine());
        msg("WAITING FOR IP", bw);
        String nip = br.readLine();
        portIp.put(portNum, nip);
    }

    private void syn() throws IOException {
        int synch = licznik;
        BufferedWriter bw = null;
        for (Map.Entry<Integer, String> entry : portIp.entrySet()) {
            if (!(entry.getKey() == this.port && entry.getValue().equals(this.ip))) {
                Socket agentSocket = new Socket(entry.getValue(), entry.getKey());
                BufferedReader br = new BufferedReader(new InputStreamReader(agentSocket.getInputStream(), "UTF-8"));
                bw = new BufferedWriter(new OutputStreamWriter(agentSocket.getOutputStream()));
                msg(requests[4], bw);
                synch += Integer.parseInt(br.readLine());
                msg(requests[3], bw);
            }
        }
        licznik = synch / portIp.size();
    }

    private void del(BufferedReader br, BufferedWriter bw) throws IOException {
        msg("WAITING IP:", bw);
        String ipToDelete = br.readLine();
        msg("WAITING PORT:", bw);
        int portToDelete = Integer.parseInt(br.readLine());
        portIp.remove(portToDelete, ipToDelete);
    }

    private void del(String ip, int port) throws IOException {
        for (Map.Entry<Integer, String> entry : portIp.entrySet()) {
            Socket otherSocket = new Socket(entry.getValue(), entry.getKey());
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(otherSocket.getOutputStream()));
            msg(requests[7], bw);
            msg(ip, bw);
            msg(port + "", bw);
            msg(requests[3], bw);
        }
    }

    private void connectToMonitor() throws IOException {
        Socket monitorSocket = new Socket(monitorIp, monitorPort);
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(monitorSocket.getOutputStream()));
        msg(requests[1], bw);
        msg(ip, bw);
        msg(port + "", bw);
        msg(requests[3], bw);

    }
}
