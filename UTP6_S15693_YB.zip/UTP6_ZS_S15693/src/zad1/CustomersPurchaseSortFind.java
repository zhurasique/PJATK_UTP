/**
 *
 *  @author Yukhymchuk Bohdan S15526
 *
 */

package zad1;

import java.io.*;
import java.util.*;

public class CustomersPurchaseSortFind {

	public String fname;
	public List<Purchase> lista;
	public double cenaJeden;
	public double cenaDwa;
	public Comparator<Purchase> poIMIE;
	public Comparator<Purchase> poIDK;

	public CustomersPurchaseSortFind() {
		lista = new ArrayList<Purchase>();
	}

	public void readFile(String fname) {
		this.fname = fname;
		try (BufferedReader br = new BufferedReader(new FileReader(fname))) {
			String line;
			while ((line = br.readLine()) != null) {
				String splitt[] = line.split(";");
				lista.add(new Purchase(splitt[0], 
									   splitt[1], 
									   splitt[2], 
									   Double.parseDouble(splitt[3]),
									   Double.parseDouble(splitt[4])));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showSortedBy(String funkcja) {
		switch (funkcja) {
		case "Koszty":
			poIMIE = new Comparator<Purchase>() {
				public int compare(Purchase jeden, Purchase dwa) {
					if (jeden.cena * jeden.liczba < dwa.cena * jeden.liczba)
						return 1;
					else if (jeden.cena == dwa.cena)
						return 0;
					return -1;
				}
			};
			break;
		case "Nazwiska":
			poIMIE = new Comparator<Purchase>() {
				public int compare(Purchase arg0, Purchase arg1) {
					return arg0.imie.compareTo(arg1.imie);
				}
			};
			break;
		}

		poIDK = new Comparator<Purchase>() {
			public int compare(Purchase jeden, Purchase dwa) {
				return jeden.idk.compareTo(dwa.idk);
			}
		};

		ArrayList<Purchase> aLista = new ArrayList<Purchase>(lista);
		aLista.sort(poIMIE.thenComparing(poIDK));
		System.out.println(funkcja);
		for (Purchase klient : aLista) {
			System.out.print(klient);
			System.out.println();
		}
		System.out.println();
	}

	public void showPurchaseFor(String idk) {
		readFile(this.fname);
		System.out.println("Klient " + idk);
		for (Purchase purchase : this.lista) {
			if (purchase.idk.equals(idk))
				System.out.println(purchase);
		}
		System.out.println();
	}
}
