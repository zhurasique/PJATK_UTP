/**
 *
 *  @author Yukhymchuk Bohdan S15526
 *
 */

package zad1;


public 
	class Purchase {
	
	public String produkt;
	public double liczba;
	public double cena;
	public String idk;
	public String imie;
	
	
	public Purchase(String idk, String imie, String produkt, double liczba, double cena){
		this.produkt = produkt;
		this.liczba = liczba;
		this.cena = cena;
		this.idk = idk;
		this.imie = imie;
	}
	
	public String toString() {
		return idk + ";" + imie + ";" + produkt + ";" + liczba + ";" + cena;
	}
}
