/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;


public interface Selector<T> { 
	boolean select(T arg);
}  
