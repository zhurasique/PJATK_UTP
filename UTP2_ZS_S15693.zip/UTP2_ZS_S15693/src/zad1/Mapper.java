/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;


public interface Mapper<T, S> { 
	S map (T arg);
}  
