/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;

public class ListCreator<T> { 
	
	private List<T> newL;
	private ListCreator(List<T> src){
		newL = new ArrayList<>();
		newL.addAll(src);
	}
	public static <S> ListCreator<S> collectFrom(List<S> arg){
		return new ListCreator<>(arg);
		
	}
	public ListCreator<T> when(Selector<T> sobj){
		List<T> replace = new ArrayList<>();
		for (T check: newL)
			if (sobj.select(check)){
				replace.add(check);
			}
		newL = replace;
		return this;
	}
	public <S> List<S> mapEvery(Mapper<T, S> map){

		List<S> newList = new ArrayList<>();
		for (T obj: newL){
			newList.add(map.map(obj));
		}
		return newList;
	}
	
}   
