/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CustomersPurchaseSortFind {

	List<Purchase> list;

	public CustomersPurchaseSortFind() {
		list = new ArrayList<Purchase>();
	}

	public void readFile(String fname) {
		try (BufferedReader br = new BufferedReader(new FileReader(fname))) {
			String line;
			while ((line = br.readLine()) != null) {
				String arr[] = line.split(";");
				list.add(new Purchase(arr[0], arr[1], arr[2], Double.parseDouble(arr[3]), Double.parseDouble(arr[4])));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showSortedBy(String string) {
		Comparator<Purchase> sortByString;
		Comparator<Purchase> sortByID = new Comparator<Purchase>() {
			@Override
			public int compare(Purchase arg0, Purchase arg1) {
				return arg0.id.compareTo(arg1.id);
			}
		};
		if (string.equals("Nazwiska")) {
			sortByString = new Comparator<Purchase>() {
				@Override
				public int compare(Purchase arg0, Purchase arg1) {
					return arg0.name.compareTo(arg1.name);
				}
			};

		} else {
			sortByString = new Comparator<Purchase>() {
				@Override
				public int compare(Purchase arg0, Purchase arg1) {
					double allPrice1 = arg0.count * arg0.price;
					double allPrice2 = arg1.count * arg1.price;
					if (allPrice1 == allPrice2)
						return 0;
					else if (allPrice1 < allPrice2)
						return 1;
					else
						return -1;
				}
			};
		}
		ArrayList<Purchase> rez = new ArrayList<Purchase>(list);
		rez.sort(sortByString.thenComparing(sortByID));

		System.out.println(string);
		for (Purchase el : rez) {
			System.out.print(el);
			if (string.equals("Koszty"))
				System.out.println(" (koszt: " + el.count * el.price + ")");
			else
				System.out.println();
		}
		System.out.println();
	}

	public void showPurchaseFor(String id) {
		Object[] rez = list.stream().filter(el -> el.id.equals(id)).toArray();
		System.out.println("Klient " + id);
		for(Object el: rez) {
			System.out.println((Purchase)el);
		}
		System.out.println();
	}
}
