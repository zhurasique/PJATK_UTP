/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;


public 
	class Purchase {
	
	String id;
	String name;
	String product;
	double count;
	double price;
	
	public Purchase(String id, String name, String product, double count, double price){
		this.id = id;
		this.name = name;
		this.product = product;
		this.count = count;
		this.price = price;
	}
	
	public String toString() {
		return id + ";" + name + ";" + product + ";" + count + ";" + price;
	}
}
