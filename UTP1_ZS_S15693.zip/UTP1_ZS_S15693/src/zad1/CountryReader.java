/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zad1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;

public class CountryReader extends AbstractTableModel {

	public ArrayList<ArrayList<Object>> tab;
	public String[] tabNames;
	public BufferedReader in;
	public String[] data;

	public CountryReader(String path) throws IOException {
		super();
		in = new BufferedReader(new FileReader(path));
		String str;

		List<String> list = new ArrayList<String>();
		while ((str = in.readLine()) != null)
			list.add(str);

		Object[] stringArr = list.toArray(new String[0]);

		tab = new ArrayList<>();
		tabNames = ((String) stringArr[0]).split("\t");

		for (int i = 1; i < stringArr.length; i++){
			ArrayList<Object> tmp = new ArrayList<>(Arrays.asList(((String)stringArr[i]).split("\t")));
			tab.add(tmp);
		}
		data = new String[tab.size()];
	}

	@Override
	public int getColumnCount() {
		return tabNames.length;
	}

	@Override
	public int getRowCount() {
		return tab.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		if (columnIndex == 4) 
			return data[rowIndex];
		
		if (columnIndex >= 3 && tab.get(rowIndex).size() < columnIndex+1) 	return null;
		if (columnIndex == 3)	return new ImageIcon((String)(tab.get(rowIndex).get(columnIndex)));
		return tab.get(rowIndex).get(columnIndex);
	}

	public String getColumnName(int columnIndex) {
		return tabNames[columnIndex];
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if (columnIndex == 2)	return true;
		return false;
	}
	
	public Class getColumnClass(int columnIndex){
		if(columnIndex == 2)	return Integer.class;
		if(columnIndex == 3)	return ImageIcon.class;
		else	return String.class;
	}
	@Override
	public void setValueAt(Object value, int row, int column){
		tab.get(row).remove(column);
		tab.get(row).add(column, value);
	}
	public String[] getData(){
		return data;
	}
}
