/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zad1;

import java.io.IOException;
import javax.swing.JTable;

public 
	class CountryTable extends JTable{

	public CountryTable(String countriesFileName) throws IOException {
		super(new CountryReader(countriesFileName));
		getColumnModel().getColumn(2).setCellRenderer(new CountryRender());
		//CountryReader ctr = (CountryReader)getModel();
		getColumnModel().getColumn(2).setCellEditor(new CountryEditer(((CountryReader)getModel()).getData()));
	}

	public JTable create() {
		return this;
	}
}
