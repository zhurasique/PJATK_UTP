package zad1;

import java.awt.Component;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JTextField;

public 
	class CountryEditer extends DefaultCellEditor{
	JTextField lera;
	int prev;
	String[] date;
	int pos;
	
	
	public CountryEditer(String[] date) {
		super(new JCheckBox());
		this.date = date;
	}

	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		lera = new JTextField();
		prev = Integer.parseInt((String)(value.toString()));
		pos = row;
		return lera;
	}

	@Override
	public Object getCellEditorValue() {
		int res;
		try{
		res = Integer.parseInt(lera.getText());
		}catch(NumberFormatException ex){
			return prev;
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		this.date[pos] = dateFormat.format(date);
		return res;
	}

	@Override
	protected void fireEditingStopped() {
		super.fireEditingStopped();
	}

	
	
}
