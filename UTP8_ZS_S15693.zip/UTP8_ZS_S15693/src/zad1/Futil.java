/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad1;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class Futil {
	public static void processDir(String dirName, String resultFileName) {
		try {
			Files.createFile(Paths.get(resultFileName));
			Files.walkFileTree(Paths.get(dirName), new SimpleFileVisitor<Path>() {
				String s = "";

				public FileVisitResult visitFile(Path path, BasicFileAttributes arrs) throws IOException {
					if (path.toString().endsWith(".txt") && !path.toString().equals(Paths.get(dirName+"/"+resultFileName).toString())) {
						FileInputStream fis = new FileInputStream(path.toString());
						BufferedReader br = new BufferedReader(new InputStreamReader(fis, "Cp1250"));
						String line;
						while ((line = br.readLine()) != null)
							s += line + "\n";
						FileOutputStream fos = new FileOutputStream(resultFileName);
						BufferedWriter asswda = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
						asswda.write(s);
						asswda.close();
					}
					return FileVisitResult.CONTINUE;
				}
			});

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
