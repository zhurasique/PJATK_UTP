/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad2;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class Futil {
    static String path = "";
    static List<Path> res;
    public static void processDir(String dirName, String resultFileName){
        path = resultFileName;
        try {
            Files.createFile(Paths.get(resultFileName));
            for (Path ds: Files.newDirectoryStream(Paths.get(dirName))) {
                File tmp = ds.toFile();
                if (tmp.isDirectory())
                    findInDirectory(res,ds.toString());
                else
                    res.add(ds);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void findInDirectory(List<Path> list, String s){
        try {
            FileInputStream fis = new FileInputStream(String.valueOf(list));
            BufferedReader br = new BufferedReader(new InputStreamReader(fis, "Cp1250"));
            String line;
            while ((line = br.readLine()) != null)
                s += line + "\n";
            FileOutputStream fos = new FileOutputStream(path);
            BufferedWriter asswda = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
            asswda.write(s);
            asswda.close();
        }catch(IOException ex) {
            ex.printStackTrace();
        }
    }
}
