/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zad3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
	private static String canonicalize(String s) {
		return Stream.of(s.split("")).sorted().collect(Collectors.joining());
	}

	 public static List<String> getAnagrams(Reader reader) {
		    Map<String, Set<String>> map = new BufferedReader(reader).lines()
		                                     .flatMap(Pattern.compile("\\W+")::splitAsStream)
		                                     .collect(Collectors.groupingBy(Main::canonicalize, Collectors.toSet()));
		        return (List<String>) map.values().stream().filter(list -> list.size() > 1).collect(Collectors.toList()).stream().map( e-> {
		        	String res="";
		        	for (String tmp: e)
		        	res += tmp+ " ";
		        	res += "\n";
		        	return res;
		        	}).collect(Collectors.toList());
		    }

	public static void main(String[] args) throws Exception {
		System.out.print(getAnagrams(new InputStreamReader(new URL("http://www.puzzlers.org/pub/wordlists/unixdict.txt").openStream(),
				StandardCharsets.UTF_8)));
	}
}
